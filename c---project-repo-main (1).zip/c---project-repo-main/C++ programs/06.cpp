// write a program to convert an integer into the corresponding floating point number

#include <iostream>
using namespace std;
   
int main() {
    int num = 5;
    float f = num;
    cout << "The floating point number is: " << f << endl;
    return 0;
}

// Output: The floating point number is: 5
// Explanation: The integer 5 is converted into a floating point number 5.0.