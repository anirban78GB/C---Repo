// write a program to print 20 horizontal asterisks (*).

#include <iostream>
using namespace std;
     
int main() {
    for (int i = 0; i < 20; i++) {
        cout << "*";
    }
    cout << endl;
    return 0;
}